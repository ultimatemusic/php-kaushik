<?php
    require_once('header.php');
    require_once('sidebar.php');
    require_once('add-emploayee.php');
    require_once('footer.php');
?>
