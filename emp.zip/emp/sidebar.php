        <div class="logo-name">
            <div class="logo-image">
                <img src="asset/images/logo.png" alt="">
            </div>

            <span class="logo_name">CodingLab</span>
        </div>

        <div class="menu-items">
            <ul class="nav-links">
                <li><a href="<?php echo $mainurl; ?>Dahsboard">
                    <i class="uil uil-estate"></i>
                    <span class="link-name">Dahsboard</span>
                </a></li>
                <li><a href="<?php echo $mainurl; ?>add-employee">
                    <i class="uil uil-user-circle"></i>
                    <span class="link-name">Add Employee</span>
                </a></li>
                <li><a href="<?php echo $mainurl; ?>view-employee">
                    <i class="uil uil-chart"></i>
                    <span class="link-name">View Employee</span>
                </a></li>
                <li><a href="<?php echo $mainurl; ?>manage-employee">
                    <i class="uil uil-apps"></i>
                    <span class="link-name">Manage </span>
                </a></li>
                <li><a href="#">
                    <i class="uil uil-setting"></i>
                    <span class="link-name">Setting</span>
                </a></li>
            </ul>
            
            <ul class="logout-mode">
                <li><a href="#">
                    <i class="uil uil-signout"></i>
                    <span class="link-name">Logout</span>
                </a></li>

                
            </li>
            </ul>
        </div>
    </nav>