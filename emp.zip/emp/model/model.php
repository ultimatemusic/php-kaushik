<?php
class model{
    public $con="";
    public function __construct(){
        try {
            $this->con=new mysqli("localhost","root","","emp");
        } catch (Exception $e) {
            die(mysqli_error($this->con,$e));
        }
    }
    //add a membar function for add-employee.php
    public function insalldata($table,$data)
    {
        $key=array_keys($data);
        $key1=implode(',',$key);
        $value=array_values($data);
        $value1=implode("','",$value);
        $insert="INSERT INTO $table($key1) VALUES ('$value1')";
        $query=mysqli_query($this->con,$insert);
        return $query;

    }

    public function adminlogin($table,$email,$password)
    {
    $select="select * from $table where email='$email' and password='$password'"; 
    $query=mysqli_query($this->con,$select);
    $fetch=mysqli_fetch_array($query);
    $num_row=mysqli_num_rows($query);
        if($num_row==1)
        {
            $_SESSION["A_id"]=$fetch["A_id"];
            $_SESSION["email"]=$fetch["email"];
            return true;
        }
        else 
        {
            return false;
        }
    }

    //view employee data
    public function view_emp($table)
    {
    $select="select * from $table "; 
    $query=mysqli_query($this->con,$select);
    while($rows=mysqli_fetch_array($query))
      {
        $arr[]=$rows;
      } 
      return $arr;
    }

    //dilite employee data
    public function delite_emp($table,$emp_id)
    {
        $delete="DELETE FROM $table WHERE emp_id='$emp_id'";
        $query=mysqli_query($this->con,$delete);
        return $query;
    }



}

?>