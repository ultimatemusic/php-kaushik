<section class="dashboard" >
        <div class="dash-content">
             <div class="top">
            <i class="uil uil-bars sidebar-toggle"></i>

            <div class="search-box">
                <i class="uil uil-search"></i>
                <input type="text" placeholder="Search here...">
            </div>
            
            <img src="/asset/images/profile.jpg" alt="">
        </div>
            <div class="activity">
              <div class="title">
                    <i class="uil uil-user-circle"></i>
                    <span class="text">Add Employee</span>
                </div>
                <div class="container mt-5">
                    <table class="table">
                            <thead>
                            <tr>
                                <th>F Name</th>
                                <th>L Name</th>
                                <th>Email</th>
                                <th>phone</th>
                                <th>Address</th>
                                <th>Gendar</th>
                                <th>Edit</th>
                            </tr>
                            </thead>
                            <tbody>


                            <?php
                            //print_r($rows);

                            foreach($showdata as $rows)
                            {
                                ?>
                                <tr>
                                    <td><?php echo $rows["fname"]; ?></td>
                                    <td><?php echo $rows["lname"]; ?></td>
                                    <td><?php echo $rows["email"]; ?></td>
                                    <td><?php echo $rows["mobile"]; ?></td>
                                    <td><?php echo $rows["address"]; ?></td>
                                    <td><?php echo $rows["gendar"]; ?></td>
                                    <td><a href="<?php echo $mainurl; ?>manage-employee?emp_dilite=<?php echo $rows["emp_id"];?>"><i class="uil uil-trash"></i></a>
                                    <a href="<?php echo $mainurl; ?>manage-employee?emp_edit=<?php echo $rows["emp_id"];?>"><i class="uil uil-edit"></i></a>
                                </td>
                                </tr>
                                <?php
                            }
                            ?>
                        </tbody>
                    </table>    
                
            </div>
    </section>
