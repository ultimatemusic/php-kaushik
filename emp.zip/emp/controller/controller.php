<?php 
require_once("model/model.php");
class controller extends model 
{
    public function __construct()
    {
        parent:: __construct();
        
        if(isset($_POST["adminlogin"]))
        {
          $email=$_POST["email"];
          $password=$_POST["password"];
          $chk=$this->adminlogin('login',$email,$password);
          if($chk)
          {
            echo "<script>
            alert('You are Logged in as Admin successfully')
            window.location='./Dahsboard';
            </script>";  
          }
          else 
          {

            echo "<script>
            alert('Youe email and password are Incorect try again')
            window.location='./';
            </script>";  
          }
        }
        // view employee data
         
        $showdata=$this->view_emp('employee');

        // delete employee data
        if(isset($_GET["emp_dilite"]))
        {
            $emp_id=$_GET["emp_dilite"];
            $query=$this->delite_emp('employee',$emp_id);
            
            if($query)
            {
                echo "<script>
                alert('Employee Deleted Successfully')
                window.location='./manage-employee';
                </script>";
            }
            else 
            {
                echo "<script>
                alert('Employee Not Deleted')
                window.location='./manage-employee';
                </script>";
            }
        }
        

        // create a logic to load templates
        if(isset($_POST["addemployee"]))
             {

                $fname=$_POST['fname'];
                $lname=$_POST['lname'];
                $email=$_POST['email'];
                $mobile=$_POST['mobile'];
                $address=$_POST['address'];
                $gendar=$_POST['gender'];
                $pwd=base64_encode($_POST["password"]);
                $cpwd=base64_encode($_POST["cpassword"]);

              $data=array("fname"=>$fname,
                            "lname"=>$lname,
                            "email"=>$email,
                            "mobile"=>$mobile,
                            "address"=>$address,
                            "gendar"=>$gendar,
                            "password"=>$pwd); 
              if($pwd==$cpwd)
              {
              $this->insalldata('employee',$data);
              echo "<script>
              
              alert('New Employee Added Successfully')
              window.location='./add-employee';
              
              </script>";
              }
              else 
                {
                  echo "<script> 
              alert('Your password and confirmed password does not matched')
              window.location='./add-employee';
              
              </script>";
                }  
            }
        if(isset($_SERVER["PATH_INFO"]))
        {
            switch($_SERVER["PATH_INFO"])
            {
                case '/':
                    require_once("index.php");
                    require_once('login.php');
                    break;

                case '/Dahsboard':
                    require_once("index.php");
                    require_once('header.php');
                    require_once('sidebar.php');
                    require_once('deashboard.php');
                    require_once('footer.php');
                    break;
                
                case '/add-employee':
                    require_once("index.php");
                    require_once('header.php');
                    require_once('sidebar.php');
                    require_once('add-emploayee.php');
                    require_once('footer.php');
                    break;
                
                case '/view-employee':
                    require_once("index.php");
                    require_once('header.php');
                    require_once('sidebar.php');
                    require_once('view-employee.php');
                    require_once('footer.php');
                    break;
                
                case '/manage-employee':
                    require_once("index.php");
                    require_once('header.php');
                    require_once('sidebar.php');
                    require_once('manage.php');
                    require_once('footer.php');
                    break;

                default: 
                break;
            }
        } 
}
}
$obj=new Controller;

?>